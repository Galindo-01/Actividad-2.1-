
void main(){
  String frase="La tele letal";

  if(esPalindromo(frase)){
    print('$frase es un palindromo');
  }else{
    print('$frase no es un palindromo');
  }
}

bool esPalindromo(String frase){
  String reves=frase.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'),'');
  // replaceAll(RegExp(r'[^a-z0-9]'),''); esto hace que elimina todo lo que no sea miniscula quedando la frase lateleletal

  return reves==reves.split('').reversed.join('');
}